#!/usr/bin/env bash
# OSIRIS GNOME Terminal profiles — merge into your existing profile list
# (your other profiles are kept). Re-runnable. Pass --default to also make
# "Osiris Dark" the default profile.
set -euo pipefail
BASE="/org/gnome/terminal/legacy/profiles:"
DARK="0517150d-0d11-4700-8000-0517150d1117"
LIGHT="0517150c-f6f8-4a00-8000-0517150ff6f8"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

command -v dconf >/dev/null || { echo "dconf not found — is GNOME Terminal installed?" >&2; exit 1; }

dconf load "$BASE/:$DARK/"  < "$HERE/profile-dark.dconf"
dconf load "$BASE/:$LIGHT/" < "$HERE/profile-light.dconf"

old="$(dconf read "$BASE/list" 2>/dev/null || true)"
case "${old:-}" in
  ""|"@as []") new="['$DARK', '$LIGHT']" ;;
  *"$DARK"*)   new="$old" ;;
  *)           new="${old%]}, '$DARK', '$LIGHT']" ;;
esac
dconf write "$BASE/list" "$new"

if [ "${1:-}" = "--default" ]; then
  dconf write "$BASE/default" "'$DARK'"
  echo "Set 'Osiris Dark' as the default profile."
fi
echo "Installed 'Osiris Dark' + 'Osiris Light'. Pick them in Terminal ▸ Preferences ▸ Profiles."
